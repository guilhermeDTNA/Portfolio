<html>
    <head>
        <!-- Arquivos Bootstrap -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <script type="text/javascript" src="jquery.min.js" ></script>
    <script type="text/javascript" src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
    </head>
    <body>
        <?php
        //session_start();
        include_once './valida_login.php';
        ?>
        <div class="rodape">
            <p><center>@copyright GereCurso 2019</center></p>
        </div>
    </body>
</html>

