<html>
    <head>
    </head>
    <body>
        <?php
        //session_start();
        include_once './valida_login.php';
        ?>
        <div class="rodape">
            <p><center>@copyright GereCurso 2019</center></p>
        </div>
    </body>
</html>

